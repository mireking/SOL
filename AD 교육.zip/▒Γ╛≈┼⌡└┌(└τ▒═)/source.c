#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


// �������

int N, M, sol;
int a[30 + 10][7 + 10], B[30 + 10][7 + 10];
int sp[10], s[10];
int max;

int check(int n, int sum)
{

	return 1;
}
void DFS(int n, int sum, int m)
{
	int i;

	if (n > N)// ���� ����
	{
		if (sol < sum)
		{
			sol = sum;
		
			for (i = 1; i <= N; i++) sp[i] = s[i];
		}
		return;
	}

	for (i = 0; i <= m; i++)
	{
		s[n] = i;
		DFS(n + 1, sum + a[i][n], m - i);
	}

}

int main(void)
{
	int i, j;
	scanf("%d %d", &M, &N);

	for (i = 1; i <= M; i++)
	{
		for (j = 0; j <= N; j++)
		{
			scanf("%d", &a[i][j]);
		}
	}
	sol = 0;
	
	DFS(1, 0, M);

	printf("%d\n", sol);
	for (i = 1; i <= N; i++) printf("%d ", sp[i]);
	return 0;
}


