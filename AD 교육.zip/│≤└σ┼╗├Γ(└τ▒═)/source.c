/*
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


// ���� Ż��
// n : �ǹ���ȣ

int N, W[20 * 20 + 10];
int max;

int check(int n, int sum)
{
	int i, nTmpn, nTmpSum;
	nTmpn = W[n];
	nTmpSum = sum;
	for (i = 10; i <= 100000000; i *= 10)
	{
		nTmpn = nTmpn % 10;
		nTmpSum = nTmpSum % 10;
		if (nTmpn + nTmpSum >= 10)
		{
			return 0;
		}
		nTmpn = W[n] / i;
		nTmpSum = sum / i;
		if (nTmpn == 0 && nTmpSum == 0) break;
	}
	return 1;
}
void DFS(int n, int cnt, int sum)
{
	int i;

	if (n > N)// ���� ����
	{
		return;
	}

	if (cnt > max) max = cnt;
	if (check(n, sum))
	{
		printf("Check True n : %d, cnt : %d, sum : %d, W[n] : %d  \n",n ,cnt ,sum, W[n]);
		DFS(n + 1, cnt + 1 , sum + W[n]);	// ���ڸ� ������ ���
	}
	else
	{
		printf("Check False n : %d, cnt : %d, sum : %d, W[n] : %d  \n", n, cnt, sum, W[n]);
	}
	printf(" n : %d, cnt : %d, sum : %d \n", n, cnt, sum);
	DFS(n + 1, cnt, sum);					// �������� �ʴ� ���
}

int main(void)
{
	int i;
	scanf("%d", &N);

	for (i = 1; i <= N; i++)
	{
		scanf("%d", &W[i]);
	}
	max = 1;
	DFS(1, 1, 0);

	printf("%d", max);
	return 0;
}

*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


// ���� Ż��
// n : �ǹ���ȣ

int N, W[20 * 20 + 10];
int max;

void DFS(int n, int cnt, int sum)
{
	int i, nTmpn, nTmpSum;
	int flag;

	if (n > N)// ���� ����
	{
		return;
	}
	//if (n > 1)
	{
		nTmpn = W[n];
		nTmpSum = sum;
		//printf(" %d + %d = %d  \n",nTmpSum ,nTmpn ,nTmpSum  +nTmpn );
		for (i = 10; i <= 100000000; i *= 10)
		{
			nTmpn = nTmpn % 10;
			nTmpSum = nTmpSum % 10;
			if (nTmpn + nTmpSum >= 10)
			{
				//flag = 1;
				//printf(" %d + %d = FAIL \n", nTmpSum,nTmpn );
				DFS(n + 1, cnt, sum);				// �������� �ʴ� ���
				return;
			}

			nTmpn = W[n] / i;
			nTmpSum = sum / i;

			if (nTmpn == 0 && nTmpSum == 0) break;
		}
	}
	//printf(" %d + %d = TRUE cnt %d\n", sum, W[n], cnt);
	if (cnt > max) max = cnt;
	DFS(n + 1, cnt + 1, sum + W[n]);	// ���ڸ� ������ ���
										//DFS(n + 2, cnt + 1, sum + W[n]);	// �������� �ʴ� ���
	DFS(n + 1, cnt, sum);				// �������� �ʴ� ���
}

int main(void)
{
	int i;
	scanf("%d", &N);

	for (i = 1; i <= N; i++)
	{
		scanf("%d", &W[i]);
	}
	max = 0;
	DFS(1, 1, 0);

	printf("%d", max);
	return 0;
}