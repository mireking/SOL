#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>



// ���� ��������
typedef struct {
	int i, j, d;
}Q_T;

Q_T Q[100 * 100 + 10];
int N, sol, rp, wp;
int a[100 + 10][100 + 10];
int chk[100 + 10][100 + 10];
int di[] = { -1, -1, -1,  1, 1, 1,  0, 0};
int dj[] = { -1,  0,  1, -1, 0, 1, -1, 1};

void Fill(int i, int j)
{
	int k, ni, nj;
	if (chk[i][j] == 1) return;
	chk[i][j] = 1;

	for (k = 0; k < 8; k++)
	{
		ni = i + di[k];
		nj = j + dj[k];
		if (ni < 1 || ni > N || nj < 1 || nj > N) continue;
		if (a[ni][nj] != 1) continue;
		Fill(ni, nj);
	}
}


int main(void)
{
	int i, j,  remain;
	scanf("%d", &N);

	for (i = 1; i <= N; i++)
	{
		for (j = 1; j <= N; j++)
		{
			scanf("%1d", &a[i][j]);
		}
	}

	for (i = 1; i <= N; i++)
	{
		for (j = 1; j <= N; j++)
		{
			if (a[i][j] == 1 && chk[i][j] == 0)
			{
				Fill(i, j);
				sol++;
			}
		}
	}

	printf("%d", sol);

	return 0;
}

