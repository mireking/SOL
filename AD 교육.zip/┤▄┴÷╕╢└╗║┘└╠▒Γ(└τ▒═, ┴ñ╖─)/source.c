#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>



// ���� ��ȣ ���̱�

int N, sol;
int a[25 + 10][25 + 10];
int chk[25 + 10][25 + 10];
int maul[25 * 25 + 10];

// 8��
//int di[] = { -1, -1, -1,  1, 1, 1,  0, 0};
//int dj[] = { -1,  0,  1, -1, 0, 1, -1, 1};
// 4��
int di[] = { 0,0,1,-1 };
int dj[] = { 1,-1,0,0 };

void Fill(int i, int j)
{
	int k, ni, nj;
	if (chk[i][j] == 1) return;
	chk[i][j] = 1;
	maul[sol]++;

	for (k = 0; k < 4; k++)
	{
		ni = i + di[k];
		nj = j + dj[k];
		if (ni < 1 || ni > N || nj < 1 || nj > N) continue;
		if (a[ni][nj] != 1) continue;
		Fill(ni, nj);
	}
}


int main(void)
{
	int i, j,  remain;
	scanf("%d", &N);

	for (i = 1; i <= N; i++)
	{
		for (j = 1; j <= N; j++)
		{
			scanf("%1d", &a[i][j]);
		}
	}
	sol = 0;
	for (i = 1; i <= N; i++)
	{
		for (j = 1; j <= N; j++)
		{
			if (a[i][j] == 1 && chk[i][j] == 0)
			{

				Fill(i, j);
				sol++;
			}
		}
	}

	printf("%d", sol);

	int temp;
	int cordi = 0;
	for (i = 0; i < sol; i++)
	{
		for (j = i; j < sol; j++)
		{
			if (maul[i] > maul[j])
			{
				temp = maul[i];
				maul[i] = maul[j];
				maul[j] = temp;
			}
		}
		printf("\n%d", maul[i]);
	}

	return 0;
}

