#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>



// ö�� �����ϱ�

int N, M, K, sol;
int a[50 + 10][50 + 10];
int chk[50 + 10];
int connect[50 * 50 + 10];
int s[50 * 50 + 10];
int t;
int cnt;

// 8��
//int di[] = { -1, -1, -1,  1, 1, 1,  0, 0};
//int dj[] = { -1,  0,  1, -1, 0, 1, -1, 1};
// 4��
//int di[] = { 0,0,1,-1 };
//int dj[] = { 1,-1,0,0 };

void Fill(int i)
{
	int j;
	if (chk[i] == 1) return;
	chk[i] = 1;
	t++;
	for (j = 1; j <= N; j++)
	{
		if (a[i][j] == 1 && chk[j] == 0)
		{
			Fill(j);
		}
	}
}

int main(void)
{
	int i, j;
	sol = 0;
	scanf("%d %d %d", &N, &M, &K);

	for (i = 1; i <= M; i++)
	{
		scanf("%d %d", &i, &j);
		a[i][j] = 1;
		a[j][i] = 1;
	}
	cnt = 0;
	for (i = 1; i <= N; i++)
	{
		t = 0; 
		Fill(i); 
		s[cnt] = t;
		cnt++;
	}

	// �������� ����
	// 
	int tmp;
	for (i = 1; i <= N; i++)
	{
		for (j = 1; j <= N; j++)
		{
			if (s[i] < s[j])
			{
				tmp = s[i]; s[i] = s[j]; s[j] = tmp;
			}
		}
	}

	printf("%d", sol);

	return 0;
}

