#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

typedef struct {
	int x, y, d;
}Q_T;

Q_T Q[100 * 100 + 10];
int X, Y, sx, sy, ex, ey, sol, readQ, writeQ;
int map[110][110];
int chkmap[110][110];
int dx[] = { 0,0,-1,1 };
int dy[] = { -1,1,0,0 };

int BFS01(void)
{
	int i;
	int tx, ty, td;
	int nearX, nearY;
	tx = sx;
	ty = sy;
	td = 0;
	readQ = 0;
	writeQ = 0;

	// �ʱ�ȭ
	Q[writeQ].x = sx;
	Q[writeQ].y = sy;
	Q[writeQ].d = 0;
	writeQ++;

	while(readQ < writeQ)
	{ 
		tx = Q[readQ].x;
		ty = Q[readQ].y;
		td = Q[readQ].d;
		readQ++;


		if (tx == ex && ty == ey)
		{
			return td;
		}

		for (i = 0; i < 4; i++)
		{
			nearX = tx + dx[i];
			nearY = ty + dy[i];
	
			if (nearX < 1 || nearX > X || nearY < 1 || nearY > Y) continue;	// �迭 ����
			if (chkmap[nearX][nearY] == 1) continue;						// �湮
			if (map[nearX][nearY] == 1) continue;							// �� ��
			Q[writeQ].x = nearX;
			Q[writeQ].y = nearY;
			Q[writeQ].d = td + 1;
			writeQ++;
			chkmap[nearX][nearY] = 1;
		}
		
	}

	return -1;
}

int main(void)
{
	int i, j, sol;
	scanf("%d %d", &X, &Y);
	scanf("%d %d %d %d", &sx, &sy, &ex, &ey);
	for (i = 1; i <= Y; i++)
	{
		for (j = 1; j <= X; j++)
		{
			scanf("%1d", &map[j][i]);
		}
	}
	sol = BFS01();

	printf("%d", sol);



	return 0;
}
