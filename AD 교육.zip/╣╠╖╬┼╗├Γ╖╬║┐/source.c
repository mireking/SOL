#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

typedef struct {
	int i, j, d;
}Q_T;

Q_T Q[100 * 100 + 10];
int C, R, sc, sr, ec, er, sol, rp, wp;
int a[100 + 10][100 + 10];
int chk[100 + 10][100 + 10];
int di[] = { -1, 1, 0, 0};
int dj[] = {  0, 0,-1, 1};
int BFS(void) 
{
	int ti, tj;	// Temp ij
	int td;		// Distance
	int ni, nj;	// Next ij
	int k;
	// Q���� �ʱ�ȭ
	rp = wp = 0; 
	Q[wp].i = sr; 
	Q[wp].j = sc; 
	Q[wp].d = 0;
	wp++;
	chk[sr][sc] = 1;
	while (rp < wp)// Q�� �����Ͱ� �ִ� ����
	{
		// ������
		ti = Q[rp].i;  
		tj = Q[rp].j;
		td = Q[rp].d;
		rp++;
		if (ti == er && tj == ec) return td;
		// ���ǿ� ������ Q�� ����
		for (k = 0; k < 4; k++)
		{
			ni = ti + di[k]; 
			nj = tj + dj[k];
			// ���� �̳�, Check �湮 ���� ��ǥ
			if (ni<1 || ni>R || nj<1 || nj>C) continue;
			if (chk[ni][nj] == 1 || a[ni][nj] == 1) continue;
			Q[wp].i = ni;
			Q[wp].j = nj;
			Q[wp].d = td + 1;
			wp++;
			chk[ni][nj] = 1;
		}
	}
	return -1;
}

int main_01(void)
{
	int i, j, sol;
	scanf("%d %d", &C, &R);
	scanf("%d %d %d %d", &sc, &sr, &ec, &er);
	for (i = 1; i <= R; i++)
	{
		for (j = 1; j <= C; j++)
		{
			scanf("%1d", &a[i][j]);
		}
	}

	sol = BFS();
	printf("%d", sol);

	return 0;
}

