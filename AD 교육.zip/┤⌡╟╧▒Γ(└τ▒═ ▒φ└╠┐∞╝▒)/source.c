#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>


// ���ϱ�
// n : �ǹ���ȣ
int T;
int no[20 + 10][2 + 10];
int va[20 + 10][20 + 10];
int chk[20 + 10];
int sol = 1000000;

int T, N, K, a[20 + 10], flag;

void DFS(int n, int sum)
{
	/*
		int i;

		//if (sum >= no[n][2]) return;// ���� �ʰ��Ȱ�� �ٷ� �Ѿ��..

		// ��������
		if (cnt > no[n][1])
		{
			if (no[n][2] != sum)
			{
				printf("NO");
			}
			else
			{
				printf("YSE");
			}
			printf("\n");
			return;
		}

		//for (i = 1; i <= no[n][1]; i++)
		//{
			if (chk[cnt] == 1) return;
			chk[cnt] = 1;
			DFS(n, cnt + 1, sum + va[n][cnt]);
		//}
	*/

	if (n > N)
	{
		if (sum == K) flag = 1;
		return;
	}

	DFS(n + 1, sum + a[n]);	// ���ڸ� ������ ���
	DFS(n + 1, sum);		// �������� �ʴ� ���
}

int main(void)
{
	/*
	int i, j;
	scanf("%d", &T);

	for (i = 1; i <= T; i++)
	{
		scanf("%d %d", &no[i][1], &no[i][2]);
		for (j = 1; j <= no[i][1]; j++)
		{
			scanf("%d", &va[i][j]);
		}
	}
	for (j = 1; j < no[i][1]; j++)
	{
		chk[j] = 0;
	}
	DFS(i, 1, 0);
	*/
	int i;
	scanf("%d", &T);
	while(T)
	{
		T--;
		scanf("%d %d", &N, &K);
		for (i = 1; i <= N; i++) scanf("%d", &a[i]);
		flag = 0;
		DFS(1, 0);
		if (flag == 1) printf("YES\n");
		else printf("NO\n");
	}

	return 0;
}

