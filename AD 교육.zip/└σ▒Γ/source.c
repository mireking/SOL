#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

// 4907 ���
typedef struct {
	int x, y, d;
}Q_T;

Q_T Q[100 * 100 + 10];
int maxX, maxY;
int bossX, bossY, zolX, zolY;
int chkmap[110][110];
int dx[] = { 1, 1,-1,-1, 2, 2,-2,-2 };
int dy[] = { 2,-2, 2,-2, 1,-1, 1,-1 };
int readQ, writeQ;
int needday;


int BFS(void) 
{
	int x, y, k;
	int tx, ty, td;
	int nearx, neary;

	readQ = 0;
	writeQ = 0;;
	needday = 0;

	Q[writeQ].x = bossX;
	Q[writeQ].y = bossY;
	Q[writeQ].d = 0;
	chkmap[bossY][bossX] = 1;
	writeQ++;

	while (readQ < writeQ)
	{
		tx = Q[readQ].x;
		ty = Q[readQ].y;
		td = Q[readQ].d;
		readQ++;

		if (tx == zolX && ty == zolY) return td;

		for (k = 0; k < 8; k++)
		{
			nearx = tx + dx[k];
			neary = ty + dy[k];
			if (nearx < 1 || neary < 1 || nearx > maxX || neary > maxY) continue;
			if (chkmap[neary][nearx] == 1) continue;		// �˻�Ϸ�

			Q[writeQ].x = nearx;
			Q[writeQ].y = neary;
			Q[writeQ].d = td + 1;
			chkmap[neary][nearx] = 1;

			writeQ++;
		}
	}


	return -1;
}

int main(void)
{
	int x, y, sol, remain;
	scanf("%d %d", &maxX, &maxY);
	scanf("%d %d %d %d", &bossX, &bossY, &zolX, &zolY);

	sol = BFS();


	printf("%d", sol);

	return 0;
}

