#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>



// ö�� �����ϱ�

int N, M, s[8 + 10];


void DFS(int n, int sum)
{
	int i;

	// ��������
	if (n > N)
	{	
		if (sum == M)
		{
			for (i = 1; i <= N; i++)
			{
				printf("%d ", s[i]);
			}
			printf("\n");
		}
		return;
	}

	for (i = 1; i <= 6; i++)
	{
		s[n] = i;
		DFS(n + 1, sum + i);
	}
}

int main(void)
{
	int i, j;
	scanf("%d %d", &N, &M);

	DFS(1, 0); 

	return 0;
}

